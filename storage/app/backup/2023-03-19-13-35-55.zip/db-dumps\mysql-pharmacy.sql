
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorys_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorys` WRITE;
/*!40000 ALTER TABLE `categorys` DISABLE KEYS */;
INSERT INTO `categorys` VALUES (1,'darzi','darzi','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(2,'shrubi mndallan','shrubi-mndallan','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(3,'3abi saresha','3abi-saresha','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(4,'shrubi zghesha','shrubi-zghesha','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(5,'mal3ami dmwchaw','mal3ami-dmwchaw','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(6,'shrub','shrub','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(7,'3ab','3ab','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(8,'krim','krim','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(9,'qatra','qatra','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(10,'mal3am','mal3am','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL);
/*!40000 ALTER TABLE `categorys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `guarantor_phone` varchar(255) DEFAULT NULL,
  `guarantor_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email_unique` (`email`),
  UNIQUE KEY `customers_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (2,'muhammad','muhammad@gmail.com','07501842910','ranya',NULL,NULL,'2023-03-14 14:24:04','2023-03-14 14:24:04'),(3,'test','test@gmail.com','09876543456','ranya',NULL,NULL,'2023-03-14 17:14:38','2023-03-14 17:14:38'),(4,'gashtyar baxtyar','gashtyar@gmail.com','07501201010','qalladzi',NULL,NULL,'2023-03-15 20:15:49','2023-03-15 20:15:49'),(5,'test2 ','test2@gmail.com','07501999999','rnaya',NULL,NULL,'2023-03-19 10:33:34','2023-03-19 10:33:34');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `debt_remains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_remains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debt_sale_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `remain` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `debt_remains_debt_sale_id_foreign` (`debt_sale_id`),
  KEY `debt_remains_customer_id_foreign` (`customer_id`),
  CONSTRAINT `debt_remains_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debt_remains_debt_sale_id_foreign` FOREIGN KEY (`debt_sale_id`) REFERENCES `debt_sales` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `debt_remains` WRITE;
/*!40000 ALTER TABLE `debt_remains` DISABLE KEYS */;
INSERT INTO `debt_remains` VALUES (1,1,2,37000,'2023-03-14 14:43:15','2023-03-14 14:43:15'),(2,2,2,14000,'2023-03-14 17:13:34','2023-03-14 17:13:34'),(3,3,3,5000,'2023-03-14 17:15:12','2023-03-14 17:15:12');
/*!40000 ALTER TABLE `debt_remains` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `debt_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `amount` int(11) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `remain` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `delete_in` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `debt_sales_sale_id_foreign` (`sale_id`),
  CONSTRAINT `debt_sales_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `debt_sales` WRITE;
/*!40000 ALTER TABLE `debt_sales` DISABLE KEYS */;
INSERT INTO `debt_sales` VALUES (1,3,87000,50000,37000,0,NULL,'2023-03-14 14:43:15','2023-03-14 14:43:15'),(2,9,34000,20000,14000,0,NULL,'2023-03-14 17:13:34','2023-03-14 17:13:34'),(3,11,5000,0,5000,0,NULL,'2023-03-14 17:15:12','2023-03-14 17:15:12');
/*!40000 ALTER TABLE `debt_sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `page` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `old_data` longtext NOT NULL,
  `new_data` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_user_id_foreign` (`user_id`),
  CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (3,2,'Login','Login','\"hogr Login to System \"','\"hogr Login to System \"','2023-03-14 13:11:16','2023-03-14 13:11:16'),(4,2,'Product','Delete','\"Delete ( test ) form : 2023-03-14 16:15:09\"','\"Delete ( test ) form : 2023-03-14 16:15:09\"','2023-03-14 13:15:09','2023-03-14 13:15:09'),(5,2,'Product','Create','\"nothing to show\"','[\"Name : test1\",\"barcode : 12122131\",\"Quantity : 100\",\"expiry Date : 2024-12-02\",\"Purches Price : 1000\",\"Sales Price : 1500\",\"Catrgory : shrub\",\"Supplier : razhan\"]','2023-03-14 13:15:59','2023-03-14 13:15:59'),(7,2,'Product','Create','\"nothing to show\"','[\"Name : test2\",\"barcode : 9876543567\",\"Quantity : 1000\",\"expiry Date : 2025-02-12\",\"Purches Price : 2000\",\"Sales Price : 2500\",\"Catrgory : qatra\",\"Supplier : muhammad\"]','2023-03-14 13:19:54','2023-03-14 13:19:54'),(8,2,'Supplier','Create','\"nothing to show\"','[\"name : test\",\"email : test@gmail.com\",\"phone : 09876545671\",\"address : ranya\",\"guarantorphone : \",\"guarantoraddress : \"]','2023-03-14 13:20:48','2023-03-14 13:20:48'),(9,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-162304453\",\"total Price : 9,000\",\"discount : 0\",\"debt : no\",\"name : test\",\"phone : 09876545671\",\"currentpaid : no paid\"]','2023-03-14 13:20:59','2023-03-14 13:20:59'),(17,2,'Login','Login','\"hogr Login to System \"','\"hogr Login to System \"','2023-03-14 17:12:35','2023-03-14 17:12:35'),(18,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-440981289\",\"total Price : 34,000\",\"discount : 0\",\"debt : yes\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : 20,000\"]','2023-03-14 17:13:34','2023-03-14 17:13:34'),(19,2,'Supplier','Create','\"nothing to show\"','[\"name : test\",\"email : test@gmail.com\",\"phone : 09876543456\",\"address : ranya\",\"guarantorphone : \",\"guarantoraddress : \"]','2023-03-14 17:14:38','2023-03-14 17:14:38'),(20,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-749149670\",\"total Price : 30,500\",\"discount : 0\",\"debt : no\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-14 17:14:42','2023-03-14 17:14:42'),(21,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-167316425\",\"total Price : 5,000\",\"discount : 0\",\"debt : yes\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-14 17:15:12','2023-03-14 17:15:12'),(22,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-665938800\",\"total Price : 4,500\",\"discount : 0\",\"debt : no\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-14 17:15:47','2023-03-14 17:15:47'),(23,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-170480914\",\"total Price : 4,000\",\"discount : 0\",\"debt : no\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-14 17:16:01','2023-03-14 17:16:01'),(24,2,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-168881711\",\"total Price : 14,500\",\"discount : 0\",\"debt : no\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-14 17:16:13','2023-03-14 17:16:13'),(28,2,'Login','Login','\"hogr Login to System \"','\"hogr Login to System \"','2023-03-15 20:17:17','2023-03-15 20:17:17'),(29,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-987775593\",\"total Price : 2,000\",\"discount : 0\",\"debt : no\",\"name : muhammad\",\"phone : 07501842910\",\"currentpaid : no paid\"]','2023-03-15 20:27:46','2023-03-15 20:27:46'),(30,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-127949331\",\"total Price : 14,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:04:11','2023-03-16 15:04:11'),(31,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-183010496\",\"total Price : 12,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:05:13','2023-03-16 15:05:13'),(32,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-427569470\",\"total Price : 8,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:27:16','2023-03-16 15:27:16'),(33,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-149171723\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:35:21','2023-03-16 15:35:21'),(34,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-208821584\",\"total Price : 2,000\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:36:50','2023-03-16 15:36:50'),(35,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-429773662\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:38:13','2023-03-16 15:38:13'),(36,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-204958304\",\"total Price : 4,000\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:41:41','2023-03-16 15:41:41'),(37,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-205721013\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:42:13','2023-03-16 15:42:13'),(38,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-257346747\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:42:48','2023-03-16 15:42:48'),(39,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-257346747\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:42:56','2023-03-16 15:42:56'),(40,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-177252120\",\"total Price : 4,000\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:47:09','2023-03-16 15:47:09'),(41,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-698349122\",\"total Price : 2,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:47:41','2023-03-16 15:47:41'),(42,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-751467502\",\"total Price : 2,000\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:47:49','2023-03-16 15:47:49'),(43,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-141208197\",\"total Price : 16,500\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-16 15:48:14','2023-03-16 15:48:14'),(44,1,'Sale','Sale','\"nothing to show\"','[\"invoice : inv-250139761\",\"total Price : 4,000\",\"discount : 0\",\"debt : no\",\"name : gashtyar baxtyar\",\"phone : 07501201010\",\"currentpaid : no paid\"]','2023-03-19 09:57:26','2023-03-19 09:57:26');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_09_13_10050_create_customers_table',1),(6,'2022_09_20_124048_create_user_details_table',1),(7,'2022_09_25_145606_create_jobs_table',1),(8,'2022_09_27_172436_create_categorys_table',1),(9,'2022_09_27_205741_create_supplier_table',1),(10,'2022_09_27_223119_create_settings_table',1),(11,'2022_09_27_404945_create_products_table',1),(12,'2022_09_28_181542_create_sales_table',1),(13,'2022_09_28_181850_create_sale_details_table',1),(14,'2022_10_13_113012_create_debt_sales_table',1),(15,'2022_10_25_130700_create_barcodes_table',1),(16,'2023_02_27_085234_create_role_table',1),(17,'2023_03_09_000912_create_logs_table',1),(18,'2023_03_09_204052_create_product_quantity',1),(19,'2023_03_13_211945_create_debt_remains_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_quantity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_quantity` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `purches_price` int(11) NOT NULL,
  `sale_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_quantity_product_id_foreign` (`product_id`),
  CONSTRAINT `product_quantity_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_quantity` WRITE;
/*!40000 ALTER TABLE `product_quantity` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_quantity` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `barcode` bigint(20) NOT NULL,
  `quantity` bigint(20) DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `purches_price` bigint(20) DEFAULT NULL,
  `sale_price` bigint(20) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_supplier_id_foreign` (`supplier_id`),
  KEY `products_user_id_foreign` (`user_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categorys` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Aspirin',421321,440,'2023-12-31',1500,2000,NULL,NULL,5,5,2,'2023-03-07 07:00:00','2023-03-19 09:57:18',NULL),(2,'Ibuprofen',12312,295,'2024-06-30',2500,3000,NULL,NULL,8,4,8,'2023-03-07 08:00:00','2023-03-16 15:18:14',NULL),(3,'Paracetamol',21313,980,'2023-11-30',2000,2500,NULL,NULL,5,3,6,'2023-03-08 05:00:00','2023-03-16 15:47:40',NULL),(4,'Amoxicillin',12321312,193,'2024-02-28',3500,4000,NULL,NULL,5,1,3,'2023-03-09 06:00:00','2023-03-16 15:43:29',NULL),(5,'Metformin',12345,99,'2024-01-31',4000,4500,NULL,NULL,9,5,8,'2023-03-10 07:00:00','2023-03-16 15:18:14',NULL),(6,'Omeprazole',67890,200,'2024-03-31',4500,5000,NULL,NULL,7,4,2,'2023-03-11 08:00:00','2023-03-14 06:52:42',NULL),(7,'Lisinopril',78901,300,'2024-04-30',5000,5500,NULL,NULL,9,4,4,'2023-03-12 09:00:00','2023-03-14 06:52:42',NULL),(8,'Atorvastatin',5678,397,'2024-05-31',5500,6000,NULL,NULL,5,8,9,'2023-03-13 10:00:00','2023-03-14 17:14:16',NULL),(9,'Simvastatin',56789,499,'2024-07-31',6000,6500,NULL,NULL,8,6,6,'2023-03-14 11:00:00','2023-03-16 15:04:05',NULL),(10,'Amlodipine',890,600,'2024-08-31',6500,7000,NULL,NULL,3,2,3,'2023-03-15 12:00:00','2023-03-14 06:52:42',NULL),(11,'Losartan',1234,700,'2024-09-30',7000,7500,NULL,NULL,6,3,4,'2023-03-16 13:00:00','2023-03-14 06:52:42',NULL),(12,'Levothyroxine',89012,799,'2024-10-31',7500,8000,NULL,NULL,4,7,2,'2023-03-17 14:00:00','2023-03-16 15:48:08',NULL),(13,'Hydrochlorothiazide',890123,897,'2024-11-30',8000,8500,NULL,NULL,10,10,2,'2023-03-18 15:00:00','2023-03-16 15:48:13',NULL),(14,'Olanzapine',8901234,1000,'2024-12-31',8500,9000,NULL,NULL,7,9,9,'2023-03-19 16:00:00','2023-03-14 06:52:42',NULL),(15,'Lamotrigine',12348901,1699,'2025-07-31',1000,2000,NULL,NULL,5,5,6,'2023-03-25 23:00:00','2023-03-14 15:23:38',NULL),(16,'Oxycodone',34560123,1900,'2025-09-30',3000,4000,NULL,NULL,6,5,8,'2023-03-28 01:00:00','2023-03-14 06:52:42',NULL),(17,'Alprazolam',45901234,2000,'2025-10-31',4000,5000,NULL,NULL,7,6,6,'2023-03-29 02:00:00','2023-03-14 06:52:42',NULL),(18,'test',987654,1000,'2023-05-12',1000,15000,'about',NULL,8,7,2,'2023-03-14 13:13:42','2023-03-14 13:15:09','2023-03-14 13:15:09'),(19,'test1',12122131,93,'2024-12-02',1000,1500,NULL,NULL,6,4,2,'2023-03-14 13:15:59','2023-03-16 15:17:50',NULL),(20,'test2',9876543567,1000,'2025-02-12',2000,2500,NULL,NULL,9,5,2,'2023-03-14 13:19:54','2023-03-14 13:19:54',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'View Dashboard',NULL,NULL),(2,'View Sales',NULL,NULL),(3,'View DebtSale',NULL,NULL),(4,'View Product',NULL,NULL),(5,'View User',NULL,NULL),(6,'View Customer',NULL,NULL),(7,'View ExpiryProduct',NULL,NULL),(8,'View StockOutProduct',NULL,NULL),(9,'View Category',NULL,NULL),(10,'View Supplier',NULL,NULL),(11,'View Barcode',NULL,NULL),(12,'View Setting',NULL,NULL),(13,'View Log',NULL,NULL),(14,'Delete DebtSale',NULL,NULL),(15,'Delete Product',NULL,NULL),(16,'Delete User',NULL,NULL),(17,'Delete Customer',NULL,NULL),(18,'Delete Category',NULL,NULL),(19,'Delete Supplier',NULL,NULL),(20,'Delete Barcode',NULL,NULL),(21,'Delete Logs',NULL,NULL),(22,'Insert Sales',NULL,NULL),(23,'Insert Product',NULL,NULL),(24,'Insert User',NULL,NULL),(25,'Insert Customer',NULL,NULL),(26,'Insert Category',NULL,NULL),(27,'Insert Supplier',NULL,NULL),(28,'Insert Barcode',NULL,NULL),(29,'Update DebtSale',NULL,NULL),(30,'Update Product',NULL,NULL),(31,'Update User',NULL,NULL),(32,'Update Customer',NULL,NULL),(33,'Update Category',NULL,NULL),(34,'Update Supplier',NULL,NULL),(35,'Update Barcode',NULL,NULL),(36,'Product Trash',NULL,NULL),(37,'User Trash',NULL,NULL),(38,'Category Trash',NULL,NULL),(39,'Supplier Trash',NULL,NULL),(40,'Clear Log',NULL,NULL),(41,'User GenerateReport',NULL,NULL),(42,'User Export',NULL,NULL),(43,'Product Export',NULL,NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sale_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_details_sale_id_foreign` (`sale_id`),
  KEY `sale_details_product_id_foreign` (`product_id`),
  CONSTRAINT `sale_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sale_details_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sale_details` WRITE;
/*!40000 ALTER TABLE `sale_details` DISABLE KEYS */;
INSERT INTO `sale_details` VALUES (1,1,19,6,'2023-03-14 13:20:13','2023-03-14 13:20:16'),(2,2,1,3,'2023-03-14 14:42:22','2023-03-14 14:42:23'),(3,3,1,36,'2023-03-14 14:42:44','2023-03-14 14:42:59'),(4,3,3,6,'2023-03-14 14:43:06','2023-03-14 14:43:08'),(5,4,1,1,'2023-03-14 15:22:58','2023-03-14 15:22:58'),(6,4,3,1,'2023-03-14 15:23:02','2023-03-14 15:23:02'),(7,4,13,1,'2023-03-14 15:23:05','2023-03-14 15:23:05'),(8,4,5,1,'2023-03-14 15:23:09','2023-03-14 15:23:09'),(9,5,1,1,'2023-03-14 15:23:18','2023-03-14 15:23:18'),(10,6,3,1,'2023-03-14 15:23:23','2023-03-14 15:23:23'),(11,7,19,1,'2023-03-14 15:23:31','2023-03-14 15:23:31'),(12,8,15,1,'2023-03-14 15:23:38','2023-03-14 15:23:38'),(13,9,1,11,'2023-03-14 17:12:48','2023-03-14 17:12:51'),(14,9,2,4,'2023-03-14 17:13:19','2023-03-14 17:13:21'),(15,10,3,5,'2023-03-14 17:14:10','2023-03-14 17:14:12'),(16,10,8,3,'2023-03-14 17:14:15','2023-03-14 17:14:16'),(17,11,1,1,'2023-03-14 17:14:57','2023-03-14 17:14:57'),(18,11,2,1,'2023-03-14 17:15:01','2023-03-14 17:15:01'),(19,12,1,1,'2023-03-14 17:15:39','2023-03-14 17:15:39'),(20,12,3,1,'2023-03-14 17:15:42','2023-03-14 17:15:42'),(21,13,4,1,'2023-03-14 17:15:57','2023-03-14 17:15:57'),(22,14,1,1,'2023-03-14 17:16:05','2023-03-14 17:16:05'),(23,14,4,1,'2023-03-14 17:16:08','2023-03-14 17:16:08'),(24,14,13,1,'2023-03-14 17:16:10','2023-03-14 17:16:10'),(29,18,4,2,'2023-03-16 15:04:00','2023-03-16 15:04:01'),(30,18,9,1,'2023-03-16 15:04:05','2023-03-16 15:04:05'),(34,20,1,1,'2023-03-16 15:22:09','2023-03-16 15:22:09'),(35,20,3,1,'2023-03-16 15:24:52','2023-03-16 15:24:52'),(36,20,4,1,'2023-03-16 15:25:57','2023-03-16 15:25:57'),(37,21,3,1,'2023-03-16 15:27:24','2023-03-16 15:27:24'),(38,22,1,1,'2023-03-16 15:36:47','2023-03-16 15:36:47'),(39,23,3,1,'2023-03-16 15:38:12','2023-03-16 15:38:12'),(40,24,4,1,'2023-03-16 15:39:06','2023-03-16 15:39:06'),(41,25,3,1,'2023-03-16 15:41:50','2023-03-16 15:41:50'),(42,26,3,1,'2023-03-16 15:42:47','2023-03-16 15:42:47'),(43,27,4,1,'2023-03-16 15:43:29','2023-03-16 15:43:29'),(44,28,3,1,'2023-03-16 15:47:40','2023-03-16 15:47:40'),(45,29,1,1,'2023-03-16 15:47:48','2023-03-16 15:47:48'),(46,30,12,1,'2023-03-16 15:48:08','2023-03-16 15:48:08'),(47,30,13,1,'2023-03-16 15:48:13','2023-03-16 15:48:13'),(48,31,1,2,'2023-03-19 09:57:16','2023-03-19 09:57:18');
/*!40000 ALTER TABLE `sale_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `total` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = Sale Finished or 0 = Sale not Finished ',
  `paid` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1:paid, 0:debt',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_user_id_foreign` (`user_id`),
  KEY `sales_customer_id_foreign` (`customer_id`),
  KEY `sales_supplier_id_foreign` (`supplier_id`),
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'inv-162304453',2,NULL,NULL,9000,0,1,1,'2023-03-14 13:20:13','2023-03-14 13:20:59'),(2,'inv-157530816',1,2,NULL,6000,0,1,1,'2023-03-14 14:42:22','2023-03-14 14:42:35'),(3,'inv-529091720',1,2,NULL,87000,0,1,0,'2023-03-14 14:42:44','2023-03-14 14:43:15'),(4,'inv-137593105',1,2,NULL,17500,0,1,1,'2023-03-14 15:22:58','2023-03-14 15:23:15'),(5,'inv-160301594',1,2,NULL,2000,0,1,1,'2023-03-14 15:23:18','2023-03-14 15:23:20'),(6,'inv-100230061',1,2,NULL,2500,0,1,1,'2023-03-14 15:23:23','2023-03-14 15:23:26'),(7,'inv-793627048',1,2,NULL,1500,0,1,1,'2023-03-14 15:23:31','2023-03-14 15:23:34'),(8,'inv-134754120',1,2,NULL,2000,0,1,1,'2023-03-14 15:23:38','2023-03-14 15:23:46'),(9,'inv-440981289',2,2,NULL,34000,0,1,0,'2023-03-14 17:12:48','2023-03-14 17:13:34'),(10,'inv-749149670',2,3,NULL,30500,0,1,1,'2023-03-14 17:14:10','2023-03-14 17:14:42'),(11,'inv-167316425',2,3,NULL,5000,0,1,0,'2023-03-14 17:14:57','2023-03-14 17:15:12'),(12,'inv-665938800',2,2,NULL,4500,0,1,1,'2023-03-14 17:15:39','2023-03-14 17:15:47'),(13,'inv-170480914',2,2,NULL,4000,0,1,1,'2023-03-14 17:15:57','2023-03-14 17:16:01'),(14,'inv-168881711',2,2,NULL,14500,0,1,1,'2023-03-14 17:16:05','2023-03-14 17:16:13'),(18,'inv-127949331',1,4,NULL,14500,0,1,1,'2023-03-16 15:04:00','2023-03-16 15:04:11'),(20,'inv-427569470',1,4,NULL,8500,0,1,1,'2023-03-16 15:22:09','2023-03-16 15:27:16'),(21,'inv-149171723',1,4,NULL,2500,0,1,1,'2023-03-16 15:27:24','2023-03-16 15:35:21'),(22,'inv-208821584',1,4,NULL,2000,0,1,1,'2023-03-16 15:36:47','2023-03-16 15:36:50'),(23,'inv-429773662',1,4,NULL,2500,0,1,1,'2023-03-16 15:38:12','2023-03-16 15:38:13'),(24,'inv-204958304',1,4,NULL,4000,0,1,1,'2023-03-16 15:39:06','2023-03-16 15:41:41'),(25,'inv-205721013',1,4,NULL,2500,0,1,1,'2023-03-16 15:41:50','2023-03-16 15:42:13'),(26,'inv-257346747',1,4,NULL,2500,0,1,1,'2023-03-16 15:42:47','2023-03-16 15:42:48'),(27,'inv-177252120',1,4,NULL,4000,0,1,1,'2023-03-16 15:43:29','2023-03-16 15:47:09'),(28,'inv-698349122',1,4,NULL,2500,0,1,1,'2023-03-16 15:47:40','2023-03-16 15:47:41'),(29,'inv-751467502',1,4,NULL,2000,0,1,1,'2023-03-16 15:47:48','2023-03-16 15:47:49'),(30,'inv-141208197',1,4,NULL,16500,0,1,1,'2023-03-16 15:48:08','2023-03-16 15:48:14'),(31,'inv-250139761',1,4,NULL,4000,0,1,1,'2023-03-19 09:57:16','2023-03-19 09:57:26');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Pharmacy','07500000000','gmail@gmail.com','location',NULL,'2023-03-14 06:52:43','2023-03-14 06:52:43');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'gilas','07501122110','gilas@gmail.com','iraq','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(2,'ahmad','07501122111','ahmad@gmail.com','iraq','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(3,'heshu','07502122110','heshu@gmail.com','iraq','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(4,'razhan','07502122232','razhan@gmail.com','iraq','2023-03-14 06:52:41','2023-03-14 06:52:41',NULL),(5,'muhammad','075022232','muhammad@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL),(6,'ramyar','07512122232','ramyar@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL),(7,'mihraban','07511212232','mihraban@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL),(8,'danaz','07511222232','danaz@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL),(9,'sazyar','07511222232','sazyar@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL),(10,'savyar','07511222232','savyar@gmail.com','iraq','2023-03-14 06:52:42','2023-03-14 06:52:42',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_details_user_id_foreign` (`user_id`),
  CONSTRAINT `user_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES (1,1,NULL,'Halabja','2023-03-14 06:52:41','2023-03-14 06:52:41'),(2,2,NULL,'Halabja','2023-03-14 06:52:41','2023-03-14 06:52:41'),(3,3,NULL,'ranya','2023-03-14 06:52:41','2023-03-14 06:52:41'),(4,4,NULL,'ranya','2023-03-14 06:52:41','2023-03-14 06:52:41'),(5,5,NULL,'Halabja','2023-03-14 06:52:41','2023-03-14 06:52:41'),(6,6,NULL,'Halabja','2023-03-14 06:52:41','2023-03-14 06:52:41'),(7,7,NULL,'Hawler','2023-03-14 06:52:41','2023-03-14 06:52:41'),(8,8,NULL,'Sulimany','2023-03-14 06:52:41','2023-03-14 06:52:41'),(9,9,NULL,'Sulimany','2023-03-14 06:52:41','2023-03-14 06:52:41'),(10,10,NULL,'Halabja','2023-03-14 06:52:41','2023-03-14 06:52:41'),(11,11,NULL,'ranya','2023-03-14 12:25:52','2023-03-14 12:25:52');
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `role_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`role_id`)),
  `theme` tinyint(1) DEFAULT 0 COMMENT '0->light theme , 1->dark theme',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'muhammad','hama','53608883056','ihama9728@gmail.com',NULL,'$2y$10$ctcXjGHEnw/qZCNYtNPrQe7ixZtxkLMTYbnt6sqNf69szGVE7LPhG',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-03-31 18:11:23','2023-03-14 07:32:31',NULL),(2,'hogr','hogr','45508805266','hogr@gmail.com',NULL,'$2y$10$Se.uGXz2Epr5seMD63cKVePMxfn1vvNXdQ9euhVE/7NfZcuSNYgAa',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-04-11 12:07:06','2023-03-14 06:52:41',NULL),(3,'aven','aven','5454157418','aven@gmail.com',NULL,'$2y$10$N3fnGY5n6KqbRhezsjBwtO9c.rYTVL9S03y8cV3Y25NpViBH0xyN6',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-05-20 09:41:35','2023-03-14 06:52:41',NULL),(4,'evan','evan','8836530680','evan@gmail.com',NULL,'$2y$10$WwEqR4TtsVszcvAQXqxy1O0ycVIRy3dk9FjDuE4k6Yk.fmQKmvJM.',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2023-01-17 04:42:27','2023-03-14 06:52:41',NULL),(5,'chra','chra','5896267093','chra@gmail.com',NULL,'$2y$10$Ooq8gjkRQdnXSFdS/5yvb.z8sKhzBt2ukSjmzzsFoqq3A/iVd5zIG',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-11-05 09:45:18','2023-03-14 06:52:41',NULL),(6,'redin','redin','1775338870','redin@gmail.com',NULL,'$2y$10$K40QXdSne3djEHg2iboZsOe1ZWIbcbmULq0eehlH7oYhLN/SUXHtu',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-07-01 09:43:15','2023-03-14 06:52:41',NULL),(7,'gashtyar','gashtyar','3832567713','gashtyar@gmail.com',NULL,'$2y$10$IVGLrbuG1lJ4s8QpC.4IjOYNVH3rX.FwdE4XDzmU8HE3LPy.cgmb6',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-05-14 18:53:43','2023-03-14 06:52:41',NULL),(8,'danaz','danaz','9781817823','danaz@gmail.com',NULL,'$2y$10$Ig7G6NWeFaj124CvvN0dXuVn63lhNKCUDDs.gfJUL7IM2APLtQWi6',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-08-13 03:05:31','2023-03-14 06:52:41',NULL),(9,'rekar','rekar','90587123234','rekar@gmail.com',NULL,'$2y$10$BU4e4weHBJQyk3ID7.54COHXVehyJg6TbTeg87VMckOlvsMrUHPL.',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-11-13 16:40:09','2023-03-14 06:52:41',NULL),(10,'akar','akar','19793685065','akar@gmail.com',NULL,'$2y$10$P6XOYlem.CvAWA/HbJGT4uJ6WT/icjEtYPCeDcdvQgH.HIP9hpKC2',1,'[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]',0,NULL,'2022-09-22 11:48:43','2023-03-14 13:18:48',NULL),(11,'test','test','09876545678','test@gmail.com',NULL,'$2y$10$HqOTod0ICejdBaQ6xlCbPuzFyA7NwkLPDxBQu9mcWk/kpy47FTvB.',1,'[]',0,NULL,'2023-03-14 12:25:52','2023-03-14 12:25:52',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

